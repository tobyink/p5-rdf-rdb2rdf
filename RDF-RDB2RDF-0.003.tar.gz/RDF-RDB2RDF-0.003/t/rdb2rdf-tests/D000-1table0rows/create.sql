CREATE TABLE Student (
       Name varchar(50)
);
