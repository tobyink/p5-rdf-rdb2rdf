CREATE TABLE Student (
ID integer,
Name varchar(50)
);
INSERT INTO Student (ID, Name) VALUES(10,'Venus');
