CREATE TABLE Student (
Name varchar(50) PRIMARY KEY
);
INSERT INTO Student (Name) VALUES ('Venus');
