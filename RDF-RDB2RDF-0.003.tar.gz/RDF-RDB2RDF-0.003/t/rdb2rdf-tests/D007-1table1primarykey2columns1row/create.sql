CREATE TABLE Student (
ID integer,
Name varchar(50),
PRIMARY KEY (ID)
);
INSERT INTO Student (ID, Name) VALUES(10,'Venus');
